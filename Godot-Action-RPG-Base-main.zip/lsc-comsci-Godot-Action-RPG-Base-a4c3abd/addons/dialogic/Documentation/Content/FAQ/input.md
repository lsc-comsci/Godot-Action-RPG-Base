# How to change the input?

Dialogic uses a godot `Input Action` for the so called `"action key"`. You can create a new `Input Action` in the `Project Settings` under `Input Map`. Then you can select the action key in the dialogic settings. 

This way you can use anything from mouse buttons to controler buttons or all of them together.