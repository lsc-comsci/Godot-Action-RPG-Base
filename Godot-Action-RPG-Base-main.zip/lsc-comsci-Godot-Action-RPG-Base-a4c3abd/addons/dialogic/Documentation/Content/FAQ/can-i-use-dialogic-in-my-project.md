# What license?

**May I use Dialogic in one of my projects?**
Yes, you may use Dialogic to make any kind of game - even commercial ones! The project is developed under the [MIT License](https://github.com/coppolaemilio/dialogic/blob/master/LICENSE). All we ask is that you please remember to credit us in your project!