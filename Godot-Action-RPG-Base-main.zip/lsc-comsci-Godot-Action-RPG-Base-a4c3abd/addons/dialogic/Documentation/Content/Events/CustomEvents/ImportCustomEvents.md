# Importing custom events

It's very easy to share `custom events` because they are pretty much self-contained.
You will just need to get the folder from someone. If you have it, move it into `res://dialogic/custom-events/`.

Then enable custom events in Dialogic's settings menu (if you haven't already).
You should now find the custom event in the bottom of the event button panel on the right in the timeline editor.

*Vòila! Hope it works ;)*